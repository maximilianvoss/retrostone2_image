__author__ = "Stefan Mavrodiev"
__copyright__ = "Copyright 2017, Olimex LTD"
__license__ = "GPLv3"
__version__ = "0.2.12"
__maintainer__ = __author__
__email__ = "stefan@olimex.com"
